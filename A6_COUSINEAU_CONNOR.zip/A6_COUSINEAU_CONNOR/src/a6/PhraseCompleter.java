package a6;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * 
 * Code that reads in some common 5-word phrases, then asks the user
 * for the start of a phrase, and then provides up to N phrases
 * that start with the user input.
 * 
 * Quit by entering an empty phrase.
 * 
 * @author dejohnso and Connor Cousineau cs1410 a6
 *
 */
public class PhraseCompleter {

	/**
	 * main has been fully implemented for you.
	 * You do not need to change this documentation for this method.
	 * @param args
	 */
	public static void main(String[] args) {
		// Read the phrases text file. One phrase per line.
		
		// This file is a reduced set of phrases provided from a site that
		// does not want the full set copied onto the Internet. Please
		// just use for this assignment.
		String[] phrases = readPhrases("w5_10.txt");
		
		// The phrases must be sorted to be searched.
		// The sample file is sorted already but sort anyway.
		Arrays.sort(phrases);

		// Get input from the user until an empty line.
		String inputPhrase = null;
		Scanner input = new Scanner(System.in);
		while (true) {
			System.out.print("Please enter a starting phrase: ");
			inputPhrase = input.nextLine();
			
			if (inputPhrase.length() == 0)
				break; // This stops the loop.

			// Search for any phrase that starts with the inputPhrase.
			int index = binarySearchForPartialKeyMatch(phrases, inputPhrase);
			if (index == -1) {
				System.out.println("Phrase not found");
				continue; // skip the rest of the loop iteration
			}
			
			// Look for up to numMatches suggested phrases
			int numMatches = 7;
			// Look for up to numMatches phrases that start with the inputPhrase knowing at least one 
			// match is at index.
			String[] suggestions = getUpToNumKeyMatches(phrases, inputPhrase, index, numMatches);
			// Output the suggestions
			for (int suggestionIndex = 0; suggestionIndex < numMatches && suggestions[suggestionIndex] != null; suggestionIndex++)
				System.out.println((suggestionIndex+1) + ": " + suggestions[suggestionIndex]);
		}
		
		// Cleanup
		input.close();
		System.out.println("Session complete");
	}
	
	/**
	 * Given a phrase, return a new String that is the shorter of
	 * phrase.length() or subLength characters long.
	 * 
	 * Basically, return a substring from phrase that is the first
	 * subLength characters, unless phrase is too short, in which
	 * case return the phrase.
	 * 
	 * This method has been fully implemented for you.
	 * Use this method to help write the other methods below.
	 * You do not need to modify this documentation.
	 * 
	 * The method assumes that phrase is not null and subLength is >= 0.
	 * 
	 * @param phrase : a String 
	 * @param subLength : an int specifying how long the sub phrase should be
	 * @return a new String that is up to subLength characters long
	 */
	public static String subNCharacters(String phrase, int subLength) {
		return phrase.substring(0, Math.min(phrase.length(), subLength));
	}
	
	/**
	 *Given a key this code will find a matching phrases using the subNCharacters to find the start of the phrase.
	 *Once found it will return the location of the phrase.
	 * Assumes vals is sorted in ascending order.
	 * 
	 * @param vals : an array of phrases
	 * @param key : the start of a phrase. 
	 * @return the index where the start of val matches key, or -1 otherwise.
	 */
	public static int binarySearchForPartialKeyMatch(String[] vals, String key) {
	  
	        int lo = 0;
            int hi = vals.length - 1;
        
            while (lo <= hi) {
            
            int arrayLength = hi + 1 - lo;
            int mid = arrayLength / 2 + lo;
            int number = key.compareTo(subNCharacters(vals[mid],key.length() ));
          
            if (number == 0)
                return mid;
            else if (number > 0)
                lo = mid + 1;
            else if(number < 0)
                hi = mid - 1;
           
        }
        return -1;
	 
	}
	
	/**
	 * Given the index of a matching strings, the code will print out statements up to numMatches
	 * will always start at the top of the list.
	 * 
	 * @param phrases : an array of phrases
	 * @param key : the string that should make the beginning of returned Strings
	 * @param startIndex : the location where search found a phrase with a start matching key. 
	 * @return an array of numMatches String filled with up to numMatches matching phrases and 
	 * the rest null.
	 */
	public static String[] getUpToNumKeyMatches(String[] phrases, String key, int startIndex, int numMatches) {
	    // if 7 and up return any of the matches
	    // if there are less you need to add nulls to make the number 7
	    //while the index compare to == 0 add a that string to the array
		// need to increment the Phrases array until it no longer matches
	    String[] matching = new String[numMatches];
	    int countOfMatches = 0;
	    int index = startIndex;
	   // Basically while(true)
	    
	    while(key.compareTo(subNCharacters(phrases[index],key.length())) == 0)
	    {
	        index--;
	    }
	    if(key.compareTo(subNCharacters(phrases[index],key.length())) != 0)
	        index++;

	    while(key.compareTo(subNCharacters(phrases[index],key.length())) == 0)
	    {
	       matching[countOfMatches] = phrases[index];
	       countOfMatches++;
	       index++;
	       // when it reaches the max, it leaves the loops.
	       if(countOfMatches == numMatches)
	       {
	           break;
	       }
	    }

	    return matching; // change this code.
	}
	
	/**
	 * Reads the file at filename. The file has lines of 5 word phrases 
	 * that occur in English. 
	 * 
	 * This method has been implemented for you. It is almost the same
	 * as the method that read a file in A5.
	 * You do not need to modify this documentation.
	 * 
	 * @param filename
	 * @return An array with all the phrase lines.
	 */
	public static String[] readPhrases(String filename) {
		File file = new File(filename);
		// Count the lines in the file
		int lineCount = 0;
		try (Scanner fs = new Scanner(file)) {
			while (fs.hasNextLine()) {
				// A phrase has a line of text
				fs.nextLine();
				lineCount++;
			}
			fs.close();
		} catch (FileNotFoundException e) {
			return null;
		}
		
		// Store the lines from the file
		String[] lines = new String[lineCount];
		int count = 0;
		try (Scanner fs = new Scanner(file)) {
			while (fs.hasNextLine()) {
				String line = fs.nextLine();
				// Our sample file has tabs instead of spaces. Turn into spaces.
				line = line.replace('\u0009',  ' ');
				// get rid of a space at the beginning
				lines[count] = line.substring(1);
				count++;
			}
			fs.close();
		} catch (FileNotFoundException e) {
			return null;
		}
		
		return lines;
	}
}
