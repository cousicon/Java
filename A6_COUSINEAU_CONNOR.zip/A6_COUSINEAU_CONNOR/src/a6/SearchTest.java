package a6;

import java.util.Arrays;
import java.util.Random;

/**
 * This class has methods to compare the performance of 
 * sequential search and binary search.
 * @author dejohnso and Connor Cousineau a6 cs1410
 */
public class SearchTest {

	/**
	 * Call the test method with an array size and repetition count and output results.
	 * This method has been fully implemented for you. You may change it
	 * if it aids your investigation.
	 * @param args
	 */
	public static void main(String[] args) {
		int test_array_size = 10_000;
		int N = 100;
		double[] results = testNRepetitions(test_array_size, N);
		System.out.println("For an array of size " + test_array_size + " the average search costs are:");
		System.out.println("     binaryAvg    : " + results[0] + " equality tests");
		System.out.println("     sequentialAvg: " + results[1] + " equality tests");
		
	}
	
	/**
	 * This method constructs an int array of size arraySize and fills it with random
	 * numbers ranging from 0 to arraySize - 1 (inclusive). 
	 * 
	 * Picks a random number and finds how many == searches are performed.
	 * 
	 * Repeats this search on the same array but with a new key for N times.
	 * 
	 * Calculates the average counts for each search style.
	 * 
	 * @param arraySize: the number of elements in the test array
	 * @param N: the number of times to repeat the tests.
	 * @return a 2-element double array with the binary average at index 0 and
	 * the sequential average at index 1.
	 * 
	 * Assumes N > 0 and arraySize > 0.
	 */
	public static double[] testNRepetitions(int arraySize, int N) {
		int key = 0;
	    Random s = new Random();		
		int[] numbers = new int[arraySize];
	    randomSortedFill(numbers);
	    double[]averages = new double[2];
	    for(int count= 0; count<N;count++)
	    {
	        key = s.nextInt(arraySize);
	        averages[1] += sequentialSearchForKeyWithCount(numbers, key); 
	        averages[0] +=   binarySearchForKeyWithCount(numbers, key);  
	    }
	        averages[1] = averages[1]/N;
	        averages[0] = averages[0]/N;
	    
	    
	    return averages;
	}
	
	
	/**
	 * Given an array with length elements, fill the array
	 * with random values from 0 to length-1 (inclusive) int values.
	 * Use the Random class to generate these values.
	 * The array can have duplicate values, this is not a shuffle of 
	 * all values from 0 to length-1, but instead length values picked 
	 * randomly from 0 to length-1.
	 * 
	 * The values are then sorted in ascending order.
	 * 
	 * This method has been implemented for you.
	 * You do not need to change the documentation for this method.
	 * 
	 * @param vals: an array to be filled with random values in ascending order.
	 */
	public static void randomSortedFill(int[] vals) {
		Random generator = new Random();

		for (int index = 0; index < vals.length; index++) {
			vals[index] = generator.nextInt(vals.length);
		}
		
		Arrays.sort(vals);
	}
	
	/**
	 * Search vals for the key using binary search. 
	 * Assumes vals is sorted in ascending order.
	 * This code is provided as a reminder of how binary search works.
	 * You do not need to run it or modify it.
	 * 
	 * @param vals
	 * @param key
	 * @return the index where val is found, or -1 otherwise.
	 */
	public static int binarySearchForKey(int[] vals, int key) {
		int lo = 0;
		int hi = vals.length - 1;
		while (lo <= hi) {
			int arrayLength = hi + 1 - lo;
			int mid = arrayLength / 2 + lo;
			if (vals[mid] == key)
				return mid;
			if (vals[mid] > key)
				lo = mid + 1;
			else //if (vals[mid] > key) is the only case left, so we don't need to check it.
				hi = mid - 1;
		}
		return -1;
	}

	/**
	 * halves the search area until it finds a matching key
	 * returns number of tests 
	 * Assumes vals is sorted in ascending order.
	 * @param vals
	 * @param key
	 * @return the number of == tests performed during the search.
	 */
	public static int binarySearchForKeyWithCount(int[] vals, int key) {
	    int lo = 0;
        int hi = vals.length - 1;
        int count = 0;
        while (lo <= hi) {
            int arrayLength = hi + 1 - lo;
            int mid = arrayLength / 2 + lo;
            count++;
            if (vals[mid] == key) {
               
                return count;
            }
            if (vals[mid] < key)
            {
                lo = mid + 1;
            
            }
            else 
            {
                hi = mid - 1;
               
            }
        }
	    return count; // change this code
	}

	/**
	 * Search vals for the key using sequential search. 
	 * This code is provided as a reminder of how sequential search works.
	 * You do not need to run it or modify it.
	 * @param vals
	 * @param key
	 * @return the index where val is found, or -1 otherwise.
	 */
	public static int sequentialSearchForKey(int[] vals, int key) {
		for (int index = 0; index < vals.length; index++) {
			if (key == vals[index])
				return index;
		}
		return -1;
	}

	/**
	 * Using a count as index it searches location at count until it finds the key, incrementing the count.
	 * @param vals
	 * @param key
	 * @return the number of == tests performed during the search.
	 */
	public static int sequentialSearchForKeyWithCount(int[] vals, int key) {
	     int count = 0;
	    for (int index = 0; index < vals.length; index++) {
	        count++;
	        if (key == vals[index]) {
	                return count;
	            }
	   
	    }
	     return count;
	}


}
