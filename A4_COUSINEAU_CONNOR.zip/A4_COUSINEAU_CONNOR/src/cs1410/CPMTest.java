package cs1410;

import java.util.Scanner;

/**
 * @author dejohnso
 *
 */
public class CPMTest {
	
	
	public static void main(String[] args) {
		// Nothing to do in here
	}
	
	/**
	 * Count the number of token in sentence.
	 * @param sentence: a string of tokens
	 * @return the number of tokens
	 */
	public static int countTokens(String sentence) {
		Scanner s = new Scanner(sentence);
		int count = 0;
		while (s.hasNext()) {
			s.next();
			count++;
		}
		return count;
	}

}
