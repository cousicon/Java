package cs1410;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author dejohnso
 *
 */
public class CPMTestTest {

	@Test
	public void testEmpty() {
		assertEquals("Empty string test", 0, CPMTest.countTokens(""));
	}

	@Test
	public void testNormal() {
		assertEquals("Normal string test", 3, CPMTest.countTokens("David is cool"));
	}

}
