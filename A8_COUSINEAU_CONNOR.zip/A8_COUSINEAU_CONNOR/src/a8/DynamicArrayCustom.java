package a8;

public class DynamicArrayCustom<T> extends DynamicArray<T>{
    
    public static void main(String[] args)
    {
        
    }
    
   
    @Override
    public T[] growthStrategy(int i) {
        if (count == data.length) {
        // The move to generics causes some problems if this is split between
        // declaration and initialization, so the code is a little ugly to 
        // let this happen.
            @SuppressWarnings("unchecked")
            T[] newData =  (T[]) new Object[data.length +data.length];
            for(int j = 0; j < i; j++) {
                newData[j] = (T) data[j];
            } 
        // Leave a blank to fill in later
        // Shift the upper values
        for (int j = size(); j > i; j--) {
            newData[j] = data[j - 1];
        }
        count++;
        return newData;
        } // done at this point if the array grew
        
        // This should not execute in the growth by 1 strategy
        // Whether it is an old or new array, the upper values need to be shifted.
        for (int j = size(); j > i; j--) {
        data[j] = data[j - 1];
        }
        
        count++;
        return data;
        }
    




}
