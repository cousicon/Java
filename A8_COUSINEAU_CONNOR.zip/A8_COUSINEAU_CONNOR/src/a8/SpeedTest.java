package a8;

import java.util.Random;

public class SpeedTest {
public static void main(String[] args) {
        Random index = new Random();
        // Create an object of each array type
        DynamicArray<Integer> slowDA = new DynamicArray<Integer>();
        DynamicArrayDouble<Integer> fastDA = new DynamicArrayDouble<Integer>();
        DynamicArrayCustom<Integer> fasterDA = new DynamicArrayCustom<Integer>();
        // Set the desired number of iterations
        int N = 500;
        
        // Collect the time required to add N elements to the slow DA.
        long startTime = System.nanoTime();
        for(int i = 0; i < N; i++) {
            slowDA.add(index.nextInt(slowDA.size()+1));  // adds to anywhere in the array.
        }
        long endTime = System.nanoTime();
        System.out.println("DynamicArray took " + (endTime - startTime) / 1000000000.0 + 
                " sec to add " + N + " elements.");

        // Collect the time required to add N elements to the fast DA.
        startTime = System.nanoTime();
        for(int i = 0; i < N; i++) {
            fastDA.add(index.nextInt(fastDA.size()+1));   // adds to anywhere in the array.
        }
        endTime = System.nanoTime();
        System.out.println("DynamicArray2 took " + (endTime - startTime) / 1000000000.0 + 
                " sec to add " + N + " elements.");
    
     // Collect the time required to add N elements to the faster DA.
        startTime = System.nanoTime();
        for(int i = 0; i < N; i++) {
            fasterDA.add(index.nextInt(fasterDA.size()+1));   // adds to anywhere in the array.
        }
        endTime = System.nanoTime();
        System.out.println("DynamicArray3 took " + (endTime - startTime) / 1000000000.0 + 
                " sec to add " + N + " elements.");
    



        
}

}
