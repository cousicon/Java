package a7;


// A StringSet is a collection of non-null strings, with no duplicates
// (i.e., no two elements may be equal).  
/**
 * @author connor cousineau cs1410 a7
 * This class has a private DynamicArray2 StringSet that is private.
 *
 */
public class StringSet {
    private DynamicArray2 set; 
    // Creates an empty StringSet object
    /**
     * Creates a StringSet that uses the DynamicArray2 class.
     */
    public StringSet() {
        set = new DynamicArray2();
    }
    
    // Throws an IllegalArgumentException if e is null, otherwise adds
    // e to the set if there is not already an element in the set equal
    // to e
    /**
     * If the item is not in the string add it into the StringSet.
     * @param e The String to add.
     */
    public void insert(String e) {
        if(e == null)
            throw new  IllegalArgumentException();
            
        if(contains(e) != true)
        {
            set.add(e);
        }
    }
    
    // Throws an IllegalArgumentException if e is null, otherwise
    // indicates whether the set contains e
    /**
     * Determines if e is in the StringSet.
     * @param e The string to find. 
     * @return true if it is found. false otherwise.
     */
    public boolean contains(String e) {
        if(e == null)
            throw new  IllegalArgumentException();
        for(int j = 0; j < set.size(); j++)
        {
            if(e.equals(set.get(j)))
                return true;
        }
        
        // FILL IN
    	
	// DO NOT return false, unless appropriate. The following 
    	// statement is a temporary placeholder to prevent a 
    	// compiler error.  Remove when you implement this method.
        return false;
    }
    
    // Throws an IllegalArgumentException if e is null, otherwise
    // removes e from the set
    /**
     * removes the string e if it is found in the StringSet.
     * @param e
     */
    public void remove(String e) {
    	if(e == null)
    	   throw new  IllegalArgumentException();
    	    
    	    for(int j = 0; j < set.size(); j++)
        {
            if(e.equals(set.get(j)))
                set.remove(j);;
        }
    	        
    
    }
    
    // Returns the number of strings in the set
    /**
     * @return the size of the String Set.
     */
    public int size() {

        return set.size();
    }  
    
    // Computes and returns the union of the StringSet that calls this method and the 
    // StringSet argument to the method.
    // The original StringSets should not be changed. The union set contains every 
    // element of each of the original StringSets.
    // Throws an IllegalArgumentException if other is null.
    /**
     * Combines the object and other to form a larger StringSet.
     * @param other the StringSet to be combined
     * @return the larger StringSet.
     */
    public StringSet union(StringSet other) {
        if(other == null)
            throw new  IllegalArgumentException();
        StringSet union = new StringSet();
        
        for(int j = 0; j < set.size(); j++)
       {
           union.insert(set.get(j));
       }
        for(int i = 0; i < other.size(); i++)
        {
            union.insert(other.set.get(i));
        }

    	return  union;
    }

    // Computes and returns the intersection of the StringSet that calls this method 
    // and the StringSet argument to the method.
    // The original StringSets should not be changed. The intersection set contains 
    // only the elements that are in both of the StringSets.
    // Throws an IllegalArgumentException if other is null.
    /**
     * takes in the first String set and another String set and combines them both.
     * it only adds elements that are in both StringSets.
     * @param other StringSet to be added into the object.
     * @return the  String set containing the similarities of the object and other.
     */
    public StringSet intersection(StringSet other) {
        if(other == null)
            throw new  IllegalArgumentException();
        StringSet intersection = new StringSet();
        
        for(int j = 0; j < set.size(); j++)
        {
            intersection.insert(set.get(j));
        }
         for(int i = 0; i < other.size(); i++)
         {
             if(other.set.get(i) != set.get(i))
             intersection.insert(other.set.get(i));
         }
        
        
        
        
        // FILL IN
    	// modify the return to return the intersection.
    	return intersection;
    }

    // Returns a formatted string version of this set
    // Examples: If set contains "a" and "b", this method should 
    // return the string "{a, b}".  If the set is empty, this 
    // method should return the string "{}".
    /* 
     * returns the StringSet in a formated form.
     */
    public String toString() {
        String result = "{";
        if (size() > 0)
        result += set.get(0);

    for (int i = 1; i < size(); i++)
        result += ", " + set.get(i);

        return result + "}";
        
    	
	
    	    
    }
}