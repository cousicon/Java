package a7;


/**
 * @author connor cousineau cs1410 a7
 *
 */
public class DynamicArray2 {

    private String[] data;   // the backing array
    private int virtualArrayLength; // the number of elements in the dynamic array

    /**
     * Creates an empty dynamic array with room to grow. (DO NOT modify this method.)
     */
    public DynamicArray2 () {
        // Start with a few available spaces.
        data = new String[8];
        // But the virtual array is empty.
        virtualArrayLength = 0;
    }

    /**
     * Returns the number of elements in the dynamic array.
     * 
     * @return the number of elements
     */
    public int size () {
        return virtualArrayLength;
    }

    // Appends s to the end of the dynamic array at index this.size().
    /**
     * Takes in a string s and adds it to the dynamic array.
     * @param s a string to be added
     */
    public void add (String s) {
        add(this.size(), s);
    }

    // Throws an IndexOutOfBoundsException if i is not a valid index
    // for adding to the dynamic array, otherwise inserts s at index i.
    // Elements can be added from index 0 to this.size().
    /**
     * Adds a string s at specified location i, moving the string above it up by 1.
     * @param i location intended
     * @param s string to add
     */
    public void add (int i, String s) {
        if (i < 0 || i > data.length)
            throw new IndexOutOfBoundsException();

        if (this.size() == data.length) {

            String[] backup = new String[data.length * 2];
            for (int j = 0; j < i; j++) {
                backup[j] = data[j];
            }

            data = backup;

        }
        for (int j = data.length-1; j > i; j--) {

            data[j] = data[j - 1];
        }

        data[i] = s;
        virtualArrayLength++;

    }

    // Throws an IndexOutOfBoundsException if i is not a valid index
    // of the dynamic array, otherwise removes the element at index i
    // and shifts the elements after i down one to fill in the gap.
    /**
     * removes the specified location from the array.
     * @param i the location
     */
    public void remove (int i) {
        if (i < 0 || i >= data.length)
            throw new IndexOutOfBoundsException();

        for (int index = i; index < data.length-1; index++) {
            data[index] = data[index + 1];
        

        }
        data[data.length-1] = null;
        virtualArrayLength--;
       

      
    }

    // Throws an IndexOutOfBoundsException if i is not a valid index
    // of the dynamic array, otherwise returns the element at index i
    /**
     * gets the data from the array at the specified location i.
     * @param i the location of the data
     * @return the data at location i.
     */
    public String get (int i) {
       
        if (i < 0 || i >= data.length)
            throw new IndexOutOfBoundsException();

        return data[i];
    }

    // Throws an IndexOutOfBoundsException if i is not a valid index
    // of the dynamic array, otherwise replaces the element at index i
    // with s
    /**
     * sets the location i to the string s.
     * @param i location
     * @param s string
     */
    public void set (int i, String s) {
        if (i < 0 || i >= data.length)
            throw new IndexOutOfBoundsException();
        data[i] = s;
    }

    /**
     * Returns a formatted string version of this dynamic array.
     * 
     * @return the formatted string
     */
    public String toString () {
        String result = "[";
        if (size() > 0)
            result += get(0);

        for (int i = 1; i < size(); i++)
            result += ", " + get(i);

        return result + "] backing size: " + data.length;
    }
}
